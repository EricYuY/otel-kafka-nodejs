const opentelemetry = require('@opentelemetry/sdk-node')
const { getNodeAutoInstrumentations } = require('@opentelemetry/auto-instrumentations-node')
const { KafkaJsInstrumentation } = require('opentelemetry-instrumentation-kafkajs');
const { HapiInstrumentation } = require('@opentelemetry/instrumentation-hapi')
const { Resource } = require('@opentelemetry/resources')
const { SemanticResourceAttributes } = require('@opentelemetry/semantic-conventions')


const { diag, DiagConsoleLogger, DiagLogLevel } = require('@opentelemetry/api')
diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.ALL)

const sdk = new opentelemetry.NodeSDK({
  traceExporter: new opentelemetry.tracing.ConsoleSpanExporter(),
  instrumentations: [
    getNodeAutoInstrumentations(),
    new KafkaJsInstrumentation(),
    new HapiInstrumentation({
      enhancedDatabaseReporting: true,
    }),
  ],
  resource: new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: 'poc-api',
  }),
})

sdk.start()
