'use strict'

const initServer = require('./lib/server')

;(async () => {
  await initServer()
})()
